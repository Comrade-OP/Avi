#bgmi now
rm -rf /storage/emulated/0/Android/data/com.pubg.imobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/Paks/{core_patch_1.6.0.15531.pak,game_patch_1.6.0.15532.pak,res_pufferpatch_*}
rm -rf /storage/emulated/0/Android/data/com.pubg.imobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/{PufferEifs1,PufferEifs0,PufferTmpDir,RoleInfo,MMKV,Logs,TableDatas,UpdateInfo,apollo_*,GameErrorNoRecords,StatEventReportedFlag,Coverversion.ini}
rm -rf /storage/emulated/0/Android/data/com.pubg.imobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/{Content,Intermediate}
rm -rf /storage/emulated/0/Android/data/com.pubg.imobile/files/UE4Game/ShadowTrackerExtra/Engine
rm -rf /storage/emulated/0/Android/data/com.pubg.imobile/files/UE4Game/ShadowTrackerExtra/Epic*
rm -rf /storage/emulated/0/Android/data/com.pubg.imobile/files/{ca-bundle.pem,cacheFile.txt,login-identifier.txt}
rm -rf /storage/emulated/0/Android/data/com.pubg.imobile/cache
echo "[/Script/Client.GDolphinUpdater]
Disable=true

" > /storage/emulated/0/Android/data/com.pubg.imobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/Config/Android/Updater.ini
#Global Pubg Now 
rm -rf /storage/emulated/0/Android/data/com.tencent.ig/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/Paks/{core_patch_1.6.0.15531.pak,game_patch_1.6.0.15532.pak,res_pufferpatch_*}
rm -rf /storage/emulated/0/Android/data/com.tencent.ig/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/{PufferEifs1,PufferEifs0,PufferTmpDir,RoleInfo,MMKV,Logs,TableDatas,UpdateInfo,apollo_*,GameErrorNoRecords,StatEventReportedFlag,Coverversion.ini}
rm -rf /storage/emulated/0/Android/data/com.tencent.ig/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/{Content,Intermediate}
rm -rf /storage/emulated/0/Android/data/com.tencent.ig/files/UE4Game/ShadowTrackerExtra/Engine
rm -rf /storage/emulated/0/Android/data/com.tencent.ig/files/UE4Game/ShadowTrackerExtra/Epic*
rm -rf /storage/emulated/0/Android/data/com.tencent.ig/files/{ca-bundle.pem,cacheFile.txt,login-identifier.txt}
rm -rf /storage/emulated/0/Android/data/com.tencent.ig/cache
echo "[/Script/Client.GDolphinUpdater]
Disable=true

" > /storage/emulated/0/Android/data/com.tencent.ig/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/Config/Android/Updater.ini
#korea pubg now 
rm -rf /storage/emulated/0/Android/data/com.pubg.krmobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/Paks/{core_patch_1.6.0.15531.pak,game_patch_1.6.0.15532.pak,res_pufferpatch_*}
rm -rf /storage/emulated/0/Android/data/com.pubg.krmobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/{PufferEifs1,PufferEifs0,PufferTmpDir,RoleInfo,MMKV,Logs,TableDatas,UpdateInfo,apollo_*,GameErrorNoRecords,StatEventReportedFlag,Coverversion.ini}
rm -rf /storage/emulated/0/Android/data/com.pubg.krmobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/{Content,Intermediate}
rm -rf /storage/emulated/0/Android/data/com.pubg.krmobile/files/UE4Game/ShadowTrackerExtra/Engine
rm -rf /storage/emulated/0/Android/data/com.pubg.krmobile/files/UE4Game/ShadowTrackerExtra/Epic*
rm -rf /storage/emulated/0/Android/data/com.pubg.krmobile/files/{ca-bundle.pem,cacheFile.txt,login-identifier.txt}
rm -rf /storage/emulated/0/Android/data/com.pubg.krmobile/cache
echo "[/Script/Client.GDolphinUpdater]
Disable=true

" > /storage/emulated/0/Android/data/com.pubg.krmobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/Config/Android/Updater.ini